from django.apps import AppConfig


class ShopfirstConfig(AppConfig):
    name = 'shopfirst'
